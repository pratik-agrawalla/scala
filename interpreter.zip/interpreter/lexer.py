import sys
import re

RESERVED = 'RESERVED'
BOOL     = 'BOOL'
INT      = 'INT'
ID       = 'ID'
DATATYPE = 'DATATYPE'
PAREN    = 'PAREN'
COMMENT  = 'COMMENT'
COLON = 'COLON'

token_exprs = [
    (r'[ \n\t]+',              None),
    (r'#[^\n]*',               None),
    (r'\=',                    RESERVED),
    (r'\(',                    RESERVED),
    (r'\)',                    RESERVED),
    (r';',                     RESERVED),
    (r'\+',                    RESERVED),
    (r'-',                     RESERVED),
    (r'\*',                    RESERVED),
    (r'/',                     RESERVED),
    (r'<=',                    RESERVED),
    (r'<',                     RESERVED),
    (r'>=',                    RESERVED),
    (r'>',                     RESERVED),
    (r'!=',                    RESERVED),
    (r'=',                     RESERVED),
    (r'and',                   RESERVED),
    (r'or',                    RESERVED),
    (r'not',                   RESERVED),
    (r'if',                    RESERVED),
    (r'then',                  RESERVED),
    (r'else',                  RESERVED),
    (r'while',                 RESERVED),
    (r'do',                    RESERVED),
    (r'end',                   RESERVED),
    (r'[0-9]+',                INT),
    (r'[A-Za-z][A-Za-z0-9_]*', ID),
    (r'println',               RESERVED),
    (r'String',                DATATYPE),           ## May remove once implement classes
    (r'Int',                   DATATYPE),
    (r'Float',                 DATATYPE),
    (r'Unit',                  DATATYPE),
    (r'Bool',                  DATATYPE),
    (r'[\(\){}\[\]]',          PAREN),
    (r'\/\/[^\n]*\n*',         COMMENT),
    (r'/\*[^(\*/)]*?\*/',      COMMENT),           ##Can't figure out how to match /,.. ## no nested comments :<
    (r'object ',               RESERVED),
    (r'def ',                  RESERVED),
    (r'main',                  RESERVED),
    (r'import',                RESERVED), 
    (r'(true|false)',          BOOL),
    (r'val',				   RESERVED),
    (r':',					   COLON)
]

def imp_lex(characters):
    pos = 0
    tokens = []
    while pos < len(characters):
        match = None
        for token_expr in token_exprs:
            pattern, tag = token_expr
            regex = re.compile(pattern)
            match = regex.match(characters, pos)
            if match:
                text = match.group(0)
                if tag:
                    token = (text, tag)
                    tokens.append(token)
                break
        if not match:
            sys.stderr.write('Illegal character: %s\n' % characters[pos])
            sys.exit(1)
        else:
            pos = match.end(0)
    return tokens
